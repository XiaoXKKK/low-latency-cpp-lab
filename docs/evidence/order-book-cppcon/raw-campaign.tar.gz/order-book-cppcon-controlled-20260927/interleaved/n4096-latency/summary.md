# Measured benchmark summary

Raw data and environment: `/home/ljw/low-latency-cpp-lab/results/raw/order-book-cppcon-controlled-20260927/interleaved/n4096-latency`

Per-column median across independent rounds. Units are per row. Batch percentiles are not individual-operation tails.
Small samples cannot establish p99.9; NOT MEASURED rows have no fabricated statistics.

| Experiment | Variant | Unit / sample kind | Rounds | mean | p50 | p99 | p999 | ops/sec |
|---|---|---|---:|---:|---:|---:|---:|---:|
| order_book_latency | map_list | ns/event / single_event | 3 | 173.277 | 150.000 | 672.000 | 991.000 | — |
| order_book_latency | map_slots_ordered | ns/event / single_event | 3 | 158.982 | 140.000 | 592.090 | 871.001 | — |
| order_book_latency | map_slots_random | ns/event / single_event | 3 | 165.836 | 150.000 | 611.000 | 891.001 | — |
| order_book_latency | vector_back | ns/event / single_event | 3 | 167.320 | 141.000 | 661.000 | 1172.011 | — |
| order_book_latency | vector_branchless | ns/event / single_event | 3 | 172.483 | 130.000 | 782.000 | 1223.019 | — |
| order_book_latency | vector_front | ns/event / single_event | 3 | 1003.854 | 201.000 | 6833.200 | 11802.031 | — |
| order_book_latency | vector_linear | ns/event / single_event | 3 | 180.320 | 151.000 | 631.000 | 1242.001 | — |
