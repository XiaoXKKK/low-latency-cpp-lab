# Measured benchmark summary

Raw data and environment: `/home/ljw/low-latency-cpp-lab/results/raw/order-book-cppcon-controlled-20260927/interleaved/n256-latency`

Per-column median across independent rounds. Units are per row. Batch percentiles are not individual-operation tails.
Small samples cannot establish p99.9; NOT MEASURED rows have no fabricated statistics.

| Experiment | Variant | Unit / sample kind | Rounds | mean | p50 | p99 | p999 | ops/sec |
|---|---|---|---:|---:|---:|---:|---:|---:|
| order_book_latency | map_list | ns/event / single_event | 3 | 135.064 | 120.000 | 401.000 | 661.010 | — |
| order_book_latency | map_slots_ordered | ns/event / single_event | 3 | 127.787 | 111.000 | 351.000 | 561.001 | — |
| order_book_latency | map_slots_random | ns/event / single_event | 3 | 128.272 | 110.000 | 351.000 | 571.000 | — |
| order_book_latency | vector_back | ns/event / single_event | 3 | 124.137 | 110.000 | 380.010 | 571.000 | — |
| order_book_latency | vector_branchless | ns/event / single_event | 3 | 122.728 | 110.000 | 371.000 | 581.010 | — |
| order_book_latency | vector_front | ns/event / single_event | 3 | 143.018 | 110.000 | 661.000 | 1843.010 | — |
| order_book_latency | vector_linear | ns/event / single_event | 3 | 115.289 | 100.000 | 341.000 | 531.000 | — |
