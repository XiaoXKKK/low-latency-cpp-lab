# Measured benchmark summary

Raw data and environment: `/home/ljw/low-latency-cpp-lab/results/raw/order-book-cppcon-controlled-20260927/interleaved/n4096-throughput`

Per-column median across independent rounds. Units are per row. Batch percentiles are not individual-operation tails.
Small samples cannot establish p99.9; NOT MEASURED rows have no fabricated statistics.

| Experiment | Variant | Unit / sample kind | Rounds | mean | p50 | p99 | p999 | ops/sec |
|---|---|---|---:|---:|---:|---:|---:|---:|
| order_book_throughput | map_list | ns/event / replay_mean | 3 | 144.117 | 143.720 | 147.646 | 147.738 | 6938822 |
| order_book_throughput | map_slots_ordered | ns/event / replay_mean | 3 | 134.694 | 134.409 | 139.855 | 140.485 | 7424231 |
| order_book_throughput | map_slots_random | ns/event / replay_mean | 3 | 141.582 | 141.074 | 146.697 | 147.135 | 7063043 |
| order_book_throughput | vector_back | ns/event / replay_mean | 3 | 142.981 | 142.623 | 146.744 | 147.082 | 6993951 |
| order_book_throughput | vector_branchless | ns/event / replay_mean | 3 | 149.321 | 148.929 | 152.925 | 152.942 | 6696994 |
| order_book_throughput | vector_front | ns/event / replay_mean | 3 | 1017.573 | 990.638 | 1084.627 | 1085.121 | 982730 |
| order_book_throughput | vector_linear | ns/event / replay_mean | 3 | 155.790 | 155.337 | 159.405 | 159.558 | 6418909 |
