# Measured benchmark summary

Raw data and environment: `/home/ljw/low-latency-cpp-lab/results/raw/order-book-cppcon-controlled-20260927/interleaved/n16-latency`

Per-column median across independent rounds. Units are per row. Batch percentiles are not individual-operation tails.
Small samples cannot establish p99.9; NOT MEASURED rows have no fabricated statistics.

| Experiment | Variant | Unit / sample kind | Rounds | mean | p50 | p99 | p999 | ops/sec |
|---|---|---|---:|---:|---:|---:|---:|---:|
| order_book_latency | map_list | ns/event / single_event | 3 | 132.059 | 120.000 | 381.000 | 621.000 | — |
| order_book_latency | map_slots_ordered | ns/event / single_event | 3 | 126.114 | 110.000 | 330.000 | 531.010 | — |
| order_book_latency | map_slots_random | ns/event / single_event | 3 | 126.948 | 110.000 | 330.000 | 541.000 | — |
| order_book_latency | vector_back | ns/event / single_event | 3 | 120.062 | 110.000 | 321.000 | 501.000 | — |
| order_book_latency | vector_branchless | ns/event / single_event | 3 | 119.227 | 110.000 | 330.000 | 521.000 | — |
| order_book_latency | vector_front | ns/event / single_event | 3 | 125.435 | 110.000 | 371.000 | 671.010 | — |
| order_book_latency | vector_linear | ns/event / single_event | 3 | 110.892 | 100.000 | 281.000 | 440.001 | — |
