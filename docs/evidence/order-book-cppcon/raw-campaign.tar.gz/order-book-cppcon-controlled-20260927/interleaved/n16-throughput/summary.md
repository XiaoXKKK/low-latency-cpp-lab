# Measured benchmark summary

Raw data and environment: `/home/ljw/low-latency-cpp-lab/results/raw/order-book-cppcon-controlled-20260927/interleaved/n16-throughput`

Per-column median across independent rounds. Units are per row. Batch percentiles are not individual-operation tails.
Small samples cannot establish p99.9; NOT MEASURED rows have no fabricated statistics.

| Experiment | Variant | Unit / sample kind | Rounds | mean | p50 | p99 | p999 | ops/sec |
|---|---|---|---:|---:|---:|---:|---:|---:|
| order_book_throughput | map_list | ns/event / replay_mean | 3 | 110.274 | 109.741 | 112.484 | 112.708 | 9068317 |
| order_book_throughput | map_slots_ordered | ns/event / replay_mean | 3 | 101.264 | 101.333 | 102.768 | 103.103 | 9875186 |
| order_book_throughput | map_slots_random | ns/event / replay_mean | 3 | 101.808 | 101.759 | 104.310 | 104.510 | 9822425 |
| order_book_throughput | vector_back | ns/event / replay_mean | 3 | 94.493 | 94.312 | 97.149 | 97.499 | 10582840 |
| order_book_throughput | vector_branchless | ns/event / replay_mean | 3 | 93.508 | 93.338 | 95.385 | 95.504 | 10694316 |
| order_book_throughput | vector_front | ns/event / replay_mean | 3 | 100.889 | 100.476 | 104.332 | 104.512 | 9911839 |
| order_book_throughput | vector_linear | ns/event / replay_mean | 3 | 86.454 | 86.051 | 89.077 | 89.500 | 11566783 |
