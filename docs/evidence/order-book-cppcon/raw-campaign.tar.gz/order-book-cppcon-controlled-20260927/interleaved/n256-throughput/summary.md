# Measured benchmark summary

Raw data and environment: `/home/ljw/low-latency-cpp-lab/results/raw/order-book-cppcon-controlled-20260927/interleaved/n256-throughput`

Per-column median across independent rounds. Units are per row. Batch percentiles are not individual-operation tails.
Small samples cannot establish p99.9; NOT MEASURED rows have no fabricated statistics.

| Experiment | Variant | Unit / sample kind | Rounds | mean | p50 | p99 | p999 | ops/sec |
|---|---|---|---:|---:|---:|---:|---:|---:|
| order_book_throughput | map_list | ns/event / replay_mean | 3 | 112.442 | 112.281 | 114.495 | 114.624 | 8893480 |
| order_book_throughput | map_slots_ordered | ns/event / replay_mean | 3 | 103.500 | 103.290 | 107.428 | 107.645 | 9661849 |
| order_book_throughput | map_slots_random | ns/event / replay_mean | 3 | 104.555 | 104.347 | 105.654 | 105.661 | 9564334 |
| order_book_throughput | vector_back | ns/event / replay_mean | 3 | 100.094 | 99.909 | 102.087 | 102.150 | 9990577 |
| order_book_throughput | vector_branchless | ns/event / replay_mean | 3 | 98.239 | 98.114 | 100.414 | 100.658 | 10179296 |
| order_book_throughput | vector_front | ns/event / replay_mean | 3 | 118.365 | 117.859 | 122.069 | 122.090 | 8448408 |
| order_book_throughput | vector_linear | ns/event / replay_mean | 3 | 91.032 | 90.890 | 93.645 | 93.826 | 10985130 |
